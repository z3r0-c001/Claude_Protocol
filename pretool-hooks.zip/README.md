# PreToolUse Hooks for Claude Code

**The key insight:** Stop hooks are currently broken for blocking in Claude Code.
PreToolUse hooks with exit code 2 **do** block and feed errors back to Claude.

This package moves your quality enforcement to PreToolUse where it actually works.

## What's Included

| Hook | Purpose | Trigger |
|------|---------|---------|
| `pretool-laziness-check.py` | Blocks placeholder code, TODOs, stubs, delegation | Write\|Edit\|MultiEdit |
| `pretool-hallucination-check.py` | Verifies packages exist on PyPI/npm | Write\|Edit\|MultiEdit |
| `dangerous-command-check.py` | Blocks dangerous shell commands | Bash |
| `context-loader.py` | Injects pending violations into context | UserPromptSubmit |
| `session-init.sh` | Session setup | SessionStart |

## Installation

```bash
# Extract to your project
unzip pretool-hooks.zip -d /path/to/your/project/

# Or run the installer
cd pretool-hooks
./install-hooks.sh /path/to/your/project/

# Restart Claude Code to load hooks
```

## How It Works

When Claude tries to write code with violations:

1. Claude calls Write tool with code content
2. PreToolUse hook fires **before** the write happens
3. Hook detects lazy patterns (TODOs, placeholders, etc.)
4. Hook exits with code 2, stderr message
5. Claude Code **blocks the write** and feeds error to Claude
6. Claude must fix the issues and try again

The error message tells Claude exactly what to fix:

```
LAZINESS CHECK FAILED - Fix these issues before writing:

CRITICAL (must fix):
  Line 3: Placeholder comment found
    → // ...
  Line 2: TODO/FIXME marker found - complete the implementation
    → // TODO: implement

Provide complete, working code with no placeholders.
```

## Detection Patterns

### Laziness Check
- `// ...`, `# ...`, `/* ... */` - Placeholder comments
- `// TODO`, `# FIXME` - Incomplete markers  
- `pass`, `raise NotImplementedError` - Stub implementations
- "you could", "you'll need to", "consider adding" - Delegation phrases

### Hallucination Check
- Python imports verified against PyPI
- JavaScript imports verified against npm registry
- Standard library modules whitelisted

### Dangerous Commands
- `rm -rf /`, `rm -rf ~` - Filesystem destruction
- `chmod 777` - Dangerous permissions
- `curl | sh` - Piped execution
- Fork bombs, disk wiping commands

## Testing

```bash
# Run the test harness
python3 test-laziness-hook.py
```

## Customization

Edit the patterns in each hook to add/remove detection rules.

The severity levels are:
- `critical` - Always blocks (exit 2)
- `major` - Blocks by default (can be changed)
- `minor` - Warning only (doesn't block)

## Why PreToolUse Instead of Stop?

Claude Code's Stop hook blocking is currently broken ([GitHub Issue #3656](https://github.com/anthropics/claude-code/issues/3656)). Exit code 2 is ignored for Stop hooks.

PreToolUse hooks **do** block correctly. By catching lazy code before it's written, we prevent the problem rather than trying to clean up after.

## Files

```
.claude/
├── settings.json              # Hook configuration
├── hooks/
│   ├── pretool-laziness-check.py
│   ├── pretool-hallucination-check.py
│   ├── dangerous-command-check.py
│   ├── context-loader.py
│   └── session-init.sh
└── memory/                    # Runtime state
```

#!/bin/bash
# Install Claude Bootstrap Protocol hooks
# Usage: ./install-hooks.sh [target-directory]

set -e

TARGET_DIR="${1:-.}"
TARGET_DIR="$(cd "$TARGET_DIR" && pwd)"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  Claude Bootstrap Protocol - Hook Installation               ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""
echo "Target: $TARGET_DIR"
echo ""

# Create directory structure
CLAUDE_DIR="$TARGET_DIR/.claude"
HOOKS_DIR="$CLAUDE_DIR/hooks"
MEMORY_DIR="$CLAUDE_DIR/memory"

mkdir -p "$HOOKS_DIR"
mkdir -p "$MEMORY_DIR"

echo "✓ Created .claude directory structure"

# Copy hook scripts
HOOKS=(
    "pretool-laziness-check.py"
    "pretool-hallucination-check.py"
    "dangerous-command-check.py"
    "context-loader.py"
    "session-init.sh"
)

for hook in "${HOOKS[@]}"; do
    if [ -f "$SCRIPT_DIR/$hook" ]; then
        cp "$SCRIPT_DIR/$hook" "$HOOKS_DIR/"
        chmod +x "$HOOKS_DIR/$hook"
        echo "✓ Installed $hook"
    else
        echo "⚠ Warning: $hook not found in $SCRIPT_DIR"
    fi
done

# Install settings.json (backup existing if present)
SETTINGS_FILE="$CLAUDE_DIR/settings.json"
if [ -f "$SETTINGS_FILE" ]; then
    cp "$SETTINGS_FILE" "$SETTINGS_FILE.backup.$(date +%Y%m%d%H%M%S)"
    echo "✓ Backed up existing settings.json"
fi

if [ -f "$SCRIPT_DIR/settings.json" ]; then
    cp "$SCRIPT_DIR/settings.json" "$SETTINGS_FILE"
    echo "✓ Installed settings.json"
fi

# Test hooks
echo ""
echo "Testing hooks..."
echo ""

# Test laziness check
TEST_INPUT='{"tool_name":"Write","tool_input":{"content":"// TODO: implement","file_path":"/test.py"}}'
if echo "$TEST_INPUT" | python3 "$HOOKS_DIR/pretool-laziness-check.py" 2>/dev/null; then
    echo "⚠ Laziness check didn't block (unexpected)"
else
    EXIT_CODE=$?
    if [ $EXIT_CODE -eq 2 ]; then
        echo "✓ Laziness check blocks correctly (exit 2)"
    else
        echo "⚠ Laziness check returned unexpected exit code: $EXIT_CODE"
    fi
fi

# Test hallucination check with stdlib
TEST_INPUT='{"tool_name":"Write","tool_input":{"content":"import json","file_path":"/test.py"}}'
if echo "$TEST_INPUT" | python3 "$HOOKS_DIR/pretool-hallucination-check.py" 2>/dev/null; then
    echo "✓ Hallucination check passes stdlib (exit 0)"
else
    echo "⚠ Hallucination check incorrectly blocked stdlib"
fi

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  Installation Complete                                        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""
echo "Next steps:"
echo "  1. Restart Claude Code to load the new hooks"
echo "  2. Test with: /hooks to see registered hooks"
echo "  3. Try writing code with TODOs - should be blocked"
echo ""
echo "Files installed:"
echo "  $HOOKS_DIR/pretool-laziness-check.py"
echo "  $HOOKS_DIR/pretool-hallucination-check.py"
echo "  $HOOKS_DIR/dangerous-command-check.py"
echo "  $HOOKS_DIR/context-loader.py"
echo "  $HOOKS_DIR/session-init.sh"
echo "  $SETTINGS_FILE"
echo ""

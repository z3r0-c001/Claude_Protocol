#!/usr/bin/env python3
"""
Test harness for pretool-laziness-check.py
Run this to verify the hook catches violations correctly.
"""

import subprocess
import json
import sys

# Test cases: (name, tool_name, content, should_block)
TEST_CASES = [
    # Should BLOCK
    ("placeholder_comment", "Write", "function foo() {\n  // ...\n}", True),
    ("todo_marker", "Write", "# TODO: implement this\ndef bar(): pass", True),
    ("stub_pass", "Write", "def baz():\n    pass", True),
    ("not_implemented", "Write", "raise NotImplementedError('do this later')", True),
    ("delegation_you_could", "Write", "# you could add more validation here", True),
    ("delegation_youll_need", "Write", "// you'll need to implement auth", True),
    ("consider_adding", "Write", "// consider adding error handling", True),
    
    # Should PASS
    ("clean_code", "Write", "function add(a, b) {\n  return a + b;\n}", False),
    ("comment_with_dots_in_string", "Write", 'print("Loading...")', False),
    ("pass_in_string", "Write", 'password = "secret"', False),
    ("legitimate_code", "Write", """
def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)
""", False),
    ("read_tool_ignored", "Read", "// TODO this should be ignored", False),
]


def run_test(name: str, tool_name: str, content: str, should_block: bool) -> bool:
    """Run a single test case."""
    input_data = {
        "tool_name": tool_name,
        "tool_input": {"content": content, "file_path": "/test/file.py"},
        "session_id": "test-123",
    }
    
    try:
        result = subprocess.run(
            ["python3", "pretool-laziness-check.py"],
            input=json.dumps(input_data),
            capture_output=True,
            text=True,
            timeout=5,
        )
        
        blocked = result.returncode == 2
        
        if blocked == should_block:
            status = "✓ PASS"
            detail = ""
        else:
            status = "✗ FAIL"
            if should_block:
                detail = f" (expected block, got exit {result.returncode})"
            else:
                detail = f" (expected pass, got blocked)\n    stderr: {result.stderr[:100]}"
        
        print(f"  {status}: {name}{detail}")
        return blocked == should_block
        
    except Exception as e:
        print(f"  ✗ ERROR: {name} - {e}")
        return False


def main():
    print("Testing pretool-laziness-check.py\n")
    print("=" * 50)
    
    passed = 0
    failed = 0
    
    print("\nShould BLOCK:")
    for name, tool_name, content, should_block in TEST_CASES:
        if should_block:
            if run_test(name, tool_name, content, should_block):
                passed += 1
            else:
                failed += 1
    
    print("\nShould PASS:")
    for name, tool_name, content, should_block in TEST_CASES:
        if not should_block:
            if run_test(name, tool_name, content, should_block):
                passed += 1
            else:
                failed += 1
    
    print("\n" + "=" * 50)
    print(f"Results: {passed} passed, {failed} failed")
    
    if failed > 0:
        sys.exit(1)
    print("\nAll tests passed! Hook is ready to deploy.")


if __name__ == "__main__":
    main()
